from flask_app import app #Importamos la app
from flask import render_template,redirect,request,session,flash
from models.registro import Registro #Importamos desde models

@app.route('/')
def index():
    return render_template("contactanos.html")