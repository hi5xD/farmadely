let currentIndex = 0;

function moveSlide(direction) {
    const slides = document.querySelector('.slides');
    const totalSlides = document.querySelectorAll('.slide').length;

    // Ajustamos el índice de la imagen actual
    currentIndex = (currentIndex + direction + totalSlides) % totalSlides;

    // Mover el carrusel según el índice actual
    slides.style.transform = 'translateX(' + (-currentIndex * 100) + '%)'; // Ajuste correcto
}
