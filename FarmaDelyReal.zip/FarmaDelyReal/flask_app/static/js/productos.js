let currentIndex = 0;

function moveSlide(direction) {
    const slides = document.querySelector('.slides');
    const totalSlides = document.querySelectorAll('.slide').length;

    // Ajustamos el índice de la imagen actual
    currentIndex = (currentIndex + direction + totalSlides) % totalSlides;

    // Mover el carrusel según el índice actual
    slides.style.transform = 'translateX(' + (-currentIndex * 100) + '%)'; // Ajuste correcto
}

let currentSlideIndex = 0;

        const slideInfo = [
            "Ibuprofeno ",
            "Paracetamol",
            "Aspirina",
            "Amoxicilina.",
            "Ciprofloxacino."
        ];

        function moveSlide(direction) {
            const slides = document.querySelectorAll('.slide');
            currentSlideIndex = (currentSlideIndex + direction + slides.length) % slides.length;
            const offset = -currentSlideIndex * 100;
            document.querySelector('.slides').style.transform = `translateX(${offset}%)`;
        }

        function showInfo() {
            const infoDisplay = document.getElementById('infoDisplay');
            const medicamentoImg = document.getElementById('medicamento-imagen');

    // Información detallada para cada medicamento
            const slideDetails = [
            {
                name: "Ibuprofeno",
                details: "El ibuprofeno es un medicamento antiinflamatorio no esteroideo (AINE) que se utiliza para reducir la fiebre y aliviar el dolor.",
                img: "medicamento1.png"
            },
            {   
                name: "Paracetamol",
                details: "El paracetamol es un analgésico que se usa para tratar el dolor leve a moderado y reducir la fiebre.",
                img: "medicamento2.png"
            },
            {
                name: "Aspirina",
                details: "La aspirina se utiliza para reducir el dolor, la fiebre y la inflamación.",
                img: "medicamento3.png"
            },
            {
                name: "Amoxicilina",
                details: "La amoxicilina es un antibiótico utilizado para tratar diversas infecciones bacterianas.",
                img: "medicamento5.png"
            },
            {
                name: "Ciprofloxacino",
                details: "El ciprofloxacino es un antibiótico que se utiliza para tratar diferentes tipos de infecciones bacterianas.",
                img: "medicamento4.png"
            }
        ];

            const currentDetail = slideDetails[currentSlideIndex];
            infoDisplay.innerHTML = `<strong>${currentDetail.name}</strong><br>${currentDetail.details}`;
            medicamentoImg.src = currentDetail.img;

            const modal = document.getElementById("infoModal");
            modal.style.display = "block"; // Mostrar el modal
            }

        function closeModal() {
            const modal = document.getElementById("infoModal");
            modal.style.display = "none"; // Ocultar el modal
        }

        // Cerrar el modal al hacer clic fuera de él
        window.onclick = function(event) {
            const modal = document.getElementById("infoModal");
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }