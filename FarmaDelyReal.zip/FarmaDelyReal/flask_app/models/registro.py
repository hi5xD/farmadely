from flask_app.config.mysqlconnection import connectToMySQL #importamos desde config

class Registro:
    def __init__(self, data):
        self.id = data['id']
        self.nombre_usuario = data['nombre_usuario']
        self.email = data['email']
        self.contraseña = data['contrasela']
        self.conf_contraseña = data['conf_contraseña']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls, datos):
        query = "INSERT INTO register (nombre_usuario, email, contraseña, conf_contraseña) VALUES(%(nombre_usuario)s, %(email)s, %(contraseña)s, %(conf_contraseña)s);"
        return connectToMySQL('farmadely').query_db(query, datos)
    
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM register;"
        usuarios_en_bd = connectToMySQL('register').query_db(query)
        usuarios = []
        for usuario in usuarios_en_bd:
            usuarios.append(cls(usuario))
        return usuarios
   