from flask import Flask
from flask_app.controllers import registros

if __name__=="__main__": #Ejecutamos la aplicación

   app.run(debug=True)